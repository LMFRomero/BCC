#pragma once

#define bool char
#define true 1
#define false 0
